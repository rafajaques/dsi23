<?php
    // produtos.php
    include('variaveis.php');
    require('head.php');
?>
    <h1><?= $titulo; ?></h1>
    <p><?= $msg; ?></p>
    <h2>Produtos</h2>
    <ul>
        <li>Produto 1</li>
        <li>Produto 2</li>
    </ul>
</body>
</html>