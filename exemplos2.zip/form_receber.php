<?php
    # form_receber.php
    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];

    if ($usuario == 'rafael' && $senha == '123') {
        echo '<p>Autenticado com sucesso</p>';
    } else {
        echo '<p>Usuário ou senha inválidos</p>';
    }