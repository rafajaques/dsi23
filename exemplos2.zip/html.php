<?php
    include('variaveis.php');
    require('head.php');
?>
    <h1><?= $titulo; ?></h1>
    <p><?= $msg; ?></p>
</body>
</html>