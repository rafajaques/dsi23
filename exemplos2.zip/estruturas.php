<?php
    // estruturas.php
    $num = 0;
    $arr = [1, 2, 3];
    # echo ($arr[0]);

    if ($num > 0) {
        echo 'Maior que zero';
    } else   if ($num < 0) {
        echo 'Menor que zero';
    } else {
        echo 'Igual a zero';
    }
