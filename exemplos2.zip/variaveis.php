<?php
    // variaveis.php
    $titulo = 'Meu site';
    $msg = 'Seja bem-vindo ao site';
?>