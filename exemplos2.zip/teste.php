<?php
    // teste.php
    // Está salvo em c:/xampp/htdocs/rafael/

    echo 'abacaxi';

?>
<h1>Teste</h1>
<?php
    $variavel = 5;
    echo $variavel;